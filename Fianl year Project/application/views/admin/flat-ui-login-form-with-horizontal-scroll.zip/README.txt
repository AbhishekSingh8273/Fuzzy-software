A Pen created at CodePen.io. You can find this one at https://codepen.io/mryoun/pen/CcItK.

 http://www.dzyngiri.com/flat-ui-login-form-with-horizontal-scroll/

My 5min try to improve this demo.